package dm.profile.employeeDetail.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Table(name="employee")
@EntityListeners(AuditingEntityListener.class)

public class Employee {
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int Emp_id;
	
	@Column(name="e_name")//,nullable=false
	private String e_name;
	
	@Column(name="salary")//,nullable=false
	private String salary;
	
	@Column(name="dept_id")//,nullable=false
	private String dept_id;
	
	public int getEmp_id() {
		return Emp_id;
	}

	public void setEmp_id(int emp_id) {
		Emp_id = emp_id;
	}

	public String getEmp_name() {
		return e_name;
	}

	public void setEmp_name(String emp_name) {
		e_name = emp_name;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getDept_id() {
		return dept_id;
	}

	public void setDept_id(String dept_id) {
		this.dept_id = dept_id;
	}

	public Employee(int emp_id, String e_name, String dept_id, String salary) {
		super();
		Emp_id = emp_id;
		this.e_name = e_name;
		this.salary = salary;
		this.dept_id = dept_id;
	}
	
	

}
