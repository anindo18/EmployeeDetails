package dm.profile.employeeDetail.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import dm.profile.employeeDetail.Entity.Employee;
import dm.profile.employeeDetail.Repository.EmployeeRepository;


@RestController
@RequestMapping("/employee")
public class Controller {

	@Autowired
	private EmployeeRepository empRepository;

	


	
	// WHEN TRYING TO ACCESS ALL THE EMPLOYEES
	@GetMapping("/all")
	public List<Employee> getAllEmployees(){
		return empRepository.findAll();
	}
	
	
	// WHEN TRYING TO ACCESS ONE EMPLOYEE BY ID
	@GetMapping("/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable(value="id") Integer EmployeeId) throws Exception 
		
	{
		Employee emp = empRepository.findById(EmployeeId).orElseThrow(()->new Exception("Employee dont exist"));
				//.orElseThrow(()->new EmployeeNotFoundException("Employee "+EmployeeId+" dont exist"));
		return ResponseEntity.status(HttpStatus.OK).body(emp);
	
	}
	
	//WHEN UPDATING AN EMPLOYEE'S INFORMATION
	@PutMapping("/{id}")
	public ResponseEntity<Employee> updateEmployeeDetails(@PathVariable(value="id") Integer EmployeeId,@RequestBody Employee employeeDetail )
	{
		Employee emp = empRepository.findById(EmployeeId).orElse(null);
		emp.setEmp_id(EmployeeId);
		emp.setEmp_name(employeeDetail.getEmp_name());
		emp.setDept_id(employeeDetail.getDept_id());
		emp.setSalary(employeeDetail.getSalary());
		final Employee emp2 = empRepository.save(emp);
		return ResponseEntity.ok(emp2);
	}
	
	//WHEN SAVING A NEW EMPLOYEE INFORMATION
	@PostMapping("/save")
	public Employee createEmployees(@RequestBody Employee employeeDetails){
		return empRepository.save(employeeDetails);
	}
	
	// WHEN DELETING A NEW DATA
	@DeleteMapping("/{id}")
	public Map<String,Boolean> deleteEmployee(@PathVariable(value="id") Integer EmployeeId) throws Exception{
		Employee emp = empRepository.findById(EmployeeId).orElseThrow(()->new Exception("Employee cannot be found"));
		
		empRepository.delete(emp);
		Map<String, Boolean> response =new HashMap<>() ;
		response.put("Deleted", Boolean.TRUE);
		return response;
	}
	
	
}
