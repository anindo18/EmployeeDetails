package dm.profile.employeeDetail.Repository;


import org.springframework.data.jpa.repository.JpaRepository;

import dm.profile.employeeDetail.Entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee,Integer> {

	
}
