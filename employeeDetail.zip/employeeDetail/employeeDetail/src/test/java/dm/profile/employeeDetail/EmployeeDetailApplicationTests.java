package dm.profile.employeeDetail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDetailApplicationTests {

	@Test
	void contextLoads() {
	}

}
