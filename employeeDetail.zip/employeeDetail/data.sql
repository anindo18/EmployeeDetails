CREATE TABLE employee (
	emp_id INT(3) NOT NULL,
	e_name VARCHAR(255),
	dept_id VARCHAR(255),
	salary VARCHAR(255)
);

insert into employee(emp_id,e_name,dept_id,salary) values (1,'A','01',10000);
insert into employee(emp_id,e_name,dept_id,salary) values (2,'B','02',14000);
insert into employee(emp_id,e_name,dept_id,salary) values (3,'C','03',32000);
insert into employee(emp_id,e_name,dept_id,salary) values (4,'D','02',21000);
insert into employee(emp_id,e_name,dept_id,salary) values (5,'E','03',43000);
insert into employee(emp_id,e_name,dept_id,salary) values (6,'F','01',58000);
